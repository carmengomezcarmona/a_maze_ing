"""Tests for mazegen.pattern42."""

from __future__ import annotations

from mazegen.pattern42 import PATTERN_HEIGHT, PATTERN_WIDTH, get_blocked_cells


def _offsets(width: int, height: int) -> tuple[int, int]:
    """Reproduce the module's own (parity-safe) centring formula."""
    return width // 2 - PATTERN_WIDTH // 2, height // 2 - PATTERN_HEIGHT // 2


def test_pattern_fits_centered_in_large_enough_grid() -> None:
    width, height = 20, 12
    blocked = get_blocked_cells(width, height, required_open={(0, 0), (19, 11)})

    assert len(blocked) > 0
    xs = [x for x, _ in blocked]
    ys = [y for _, y in blocked]
    assert max(xs) - min(xs) + 1 <= PATTERN_WIDTH
    assert max(ys) - min(ys) + 1 <= PATTERN_HEIGHT
    expected_offset_x, expected_offset_y = _offsets(width, height)
    assert min(xs) == expected_offset_x
    assert min(ys) == expected_offset_y


def test_pattern_omitted_when_grid_too_small() -> None:
    blocked = get_blocked_cells(5, 5, required_open={(0, 0), (4, 4)})
    assert blocked == set()


def test_pattern_omitted_when_overlapping_required_open_cell() -> None:
    width, height = 20, 12
    offset_x, offset_y = _offsets(width, height)
    blocked = get_blocked_cells(
        width, height, required_open={(offset_x, offset_y), (19, 11)}
    )
    assert blocked == set()


def test_pattern_kept_when_corners_and_centre_do_not_overlap() -> None:
    for width, height in [(15, 10), (20, 12), (20, 15), (30, 20), (22, 14)]:
        corners_and_centre = {
            (0, 0),
            (width - 1, 0),
            (0, height - 1),
            (width - 1, height - 1),
            (width // 2, height // 2),
        }
        blocked = get_blocked_cells(width, height, required_open=corners_and_centre)
        assert len(blocked) > 0, f"pattern wrongly omitted for {width}x{height}"


def test_centre_cell_always_falls_in_the_gap_between_digits() -> None:
    """Regression test: the grid's centre column must land exactly on the
    pattern's gap column (open on every row), for ANY width, odd or even.
    """
    gap_column_local_index = PATTERN_WIDTH // 2
    for width in range(PATTERN_WIDTH, PATTERN_WIDTH + 15):
        offset_x, _ = _offsets(width, PATTERN_HEIGHT)
        centre_x = width // 2
        assert centre_x - offset_x == gap_column_local_index, (
            f"width={width}: centre column does not land on the gap"
        )
